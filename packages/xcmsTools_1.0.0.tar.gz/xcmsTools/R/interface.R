#' @export
detect_peaks <- function(wd = '.', param_file = 'params.yaml', threads = 4) {
  wd0 <- getwd()
  print(wd0)
  setwd(wd)

  params <- yaml::read_yaml(param_file)
  params$threads = threads
  params$result_folder = 'results'
  params$tmp_folder = file.path(params$result_folder, 'tmp')

  if (!dir.exists(params$tmp_folder)) {
    dir.create(params$tmp_folder, recursive = TRUE)
  }
  print(do.call(c, params))
  # sapply(params, function(x) {
  #   print(class(x))
  # })
  do.call('.detect_peaks', params)

  setwd(wd0)
}

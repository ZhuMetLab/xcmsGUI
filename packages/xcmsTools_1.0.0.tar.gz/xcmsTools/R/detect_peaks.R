.detect_peaks <- function(ppm = 25,
                          peakwidth = c(5, 30),
                          snthresh = 6,
                          mzdiff = 0.01,
                          peak_detection_method = 'centWave',
                          rt_correction_method = c('obiwarp', 'peakgroups'),
                          peak_grouping_method = 'density',
                          quant_method = c('into', 'intb', 'maxo'),
                          minfrac = 0.5,
                          minsamp = 1,
                          bw = 5,
                          mzwid = 0.015,
                          prefilter = c(3, 100),
                          use_previous = TRUE,
                          max_features = NULL,
                          plot_feature_eic = TRUE,
                          rename_table = TRUE,
                          remove_redundant = FALSE,
                          result_folder = 'results',
                          tmp_folder = 'tmp',
                          threads = 4) {
  rt_correction_method = match.arg(rt_correction_method)

  files <- list.files(pattern = "(?i)mz(X)ML",
                      recursive = TRUE,
                      full.names = TRUE)

  #=========================================
  # peak detection with xcms
  #=========================================
  .cat_line(" Detect MS peaks with xcms ")
  fntemp <- file.path(tmp_folder, "xset-")
  fn_save <- paste0(fntemp, peak_detection_method, ".rdata")
  if (.check_skip(fn_save, use_previous, TRUE)) {
    xset <- readRDS(fn_save)
  } else {
    message("Detecting MS peaks ...")
    cat("'peakwidth' was set to:",
        paste(peakwidth, collapse = "-"),
        "\n")
    if (compareVersion(as.character(packageVersion("xcms")), "1.50.0") < 0) {
      xset <- xcms::xcmsSet(files,
                            method = peak_detection_method,
                            ppm = ppm,
                            snthresh = snthresh,
                            peakwidth = peakwidth,
                            mzdiff = mzdiff,
                            prefilter = prefilter,
                            nSlaves = threads)
    } else {
      xset <- xcms::xcmsSet(files,
                            method = peak_detection_method,
                            ppm = ppm,
                            snthresh = snthresh,
                            peakwidth = peakwidth,
                            mzdiff = mzdiff,
                            prefilter = prefilter,
                            BPPARAM = .get_bpparam(threads, FALSE))
    }
    saveRDS(xset, file = fn_save, version = 2)
  }
  pd_datafile <- c('raw' = fn_save)

  sclassv <- as.character(xcms::sampclass(xset))
  smpnames <- make.names(xcms::sampnames(xset))
  smpinfo <- data.frame("sample.name" = smpnames, "group" = sclassv,
                        stringsAsFactors = FALSE)
  write.csv(smpinfo, file.path(result_folder, "sample.info.csv"),
            row.names = FALSE)
  # output the detected peak num
  for (i in 1:length(xset@filepaths)) {
    cat(i, " - ",xset@filepaths[ i], "\t [",  sclassv[ i], "]", sep = "")
    cat("  --> ", length(which(xset@peaks[, "sample"] == i)), " peaks found \n")
  }

  # output sample group information
  cat("\n Sample classes -> ", levels(xcms::sampclass(xset)), "\n")

  # RT correction for more than 1 samples
  message("Correcting retention time ...")
  if (length(files) > 1) {
    fn_save <- paste0(fntemp, "retcor.rdata")

    if (.check_skip(fn_save, use_previous, TRUE)) {
      xsetc <- readRDS(fn_save)
    } else {
      xset <- xcms::group(xset,
                          bw      = bw,
                          mzwid   = mzwid,
                          minfrac = minfrac)

      pdf(paste0("retcor-", rt_correction_method, ".pdf"))
      xsetc <- switch(
        rt_correction_method,
        "obiwarp" = xcms::retcor(xset,
                                 method   = rt_correction_method,
                                 plottype = "deviation",
                                 profStep = 0.1),
        "peakgroups" = xcms::retcor(xset,
                                    method   = rt_correction_method,
                                    plottype = "deviation")
      )
      dev.off()

      message("Creating retention time corrected tics ...")

      .get_tics(xsetc,
                fn.tic = file.path(tmp_folder, "tics-rtcor.pdf"),
                rt     = "corrected")  # total ion current

      saveRDS(xsetc, file = fn_save, version = 2)
    }
  } else {
    xsetc <- xset
  }
  pd_datafile <- c(pd_datafile, 'retcor' = fn_save)

  # peak grouping and output raw peak-table
  message("Aligning MS Peaks ...")
  fn_save <- paste0(fntemp, "group.rdata")
  if (.check_skip(fn_save, use_previous, TRUE)) {
    xset2 <- readRDS(fn_save)
  } else {
    xset2 <- xcms::group(xsetc,
                         bw      = bw,
                         mzwid   = mzwid,
                         minfrac = minfrac)

    cat(nrow(xcms::groups(xset2)), "aligned features found. \n")

    saveRDS(xset2, file = fn_save, version = 2)
    gc()
  }
  pd_datafile <- c(pd_datafile, 'grouped' = fn_save)
  groupmat <- xcms::groups(xset2)
  if (rename_table) {
    colnames(groupmat)[match(c("mzmed", "rtmed"), colnames(groupmat))] <- c("mz", "rt")
  }
  dt_quant <- xcms::groupval(xset2, "medret", quant_method)
  pk_table <- data.frame("name" = xcms::groupnames(xset2),
                         groupmat, dt_quant,
                         row.names = NULL, stringsAsFactors = FALSE)
  fn_pk <- file.path(tmp_folder, "PeakTable-raw.csv")

  write.csv(pk_table, file = fn_pk, row.names = FALSE)

  # gap filling
  message("Filling gaps ...")
  fn_save <- paste0(fntemp, "final.rdata")
  if (.check_skip(fn_save, use_previous, TRUE)) {
    xset3 <- readRDS(fn_save)
  } else {
    if (length(files) > 1) {
      xset3 <- xcms::fillPeaks(xset2) ## save for compare()
    } else {
      xset3 <- xset2
    }
    saveRDS(xset3, file = fn_save, version = 2)
    gc()
  }
  pd_datafile <- c(pd_datafile, 'final' = fn_save)

  dt_quant <- xcms::groupval(xset3, "medret", quant_method)
  pk_table <- data.frame("name" = xcms::groupnames(xset3),
                         groupmat, dt_quant,
                         row.names = NULL, stringsAsFactors = FALSE)
  rownames(pk_table) <- pk_table$name
  if (plot_feature_eic) {
    if (is.null(max_features)) {
      max_features = nrow(dt_quant)
    }
    .plot_feature_eic(xset3, dt_quant,
                      filebase = file.path(tmp_folder, "MS1_"),
                      eicmax = max_features)
  }

  fn_pk <- file.path(result_folder, "PeakTable_verbose.csv")
  cat("Saving features to csv file:", fn_pk, "...\n")
  write.csv(pk_table, fn_pk, row.names = FALSE)
  if (remove_redundant) {
    if (rename_table) {
      cols_keep <- c('name', 'mz', 'rt', colnames(dt_quant))
    } else {
      cols_keep <- c('name', 'mzmed', 'rtmed', colnames(dt_quant))
    }
    write.csv(pk_table[, cols_keep, drop = FALSE],
              file.path(result_folder, "PeakTable.csv"),
              row.names = FALSE)
  }

  if (length(xset3@filepaths) > 1) {
    message("Doing PCA analysis ...")
    values <- xcms::groupval(xset3, value = "into")
    pcaData <- t(apply(values, 2, function(dc) {
      dc / max(dc)
    }))
    pcaResult <- pcaMethods::pca(pcaData, nPcs = 3)
    pdf(file.path(tmp_folder, "PCA.pdf"))
    pcaMethods::plotPcs(pcaResult, type = "scores",
                        col = as.integer(xcms::sampclass(xset3)) + 1)
    dev.off()
  }

  # MS1 Analyzation done
  message("MS1 peak detection OK!")
}

.get_tics <- function(xsetc = NULL,
                      fn.tic = "tics.pdf",
                      rt = c("raw", "corrected")) {
  files <- xsetc@filepaths
  num_sample <- length(files)
  tics <- vector('list', num_sample)
  for (i in 1:num_sample) {
    cat(files[i], '\n')
    if (!is.null(xsetc) && rt == 'corrected') {
      rtcor <- xsetc@rt$corrected[[i]]
    }
    else rtcor <- NULL
    tics[[i]] <- .get_tic(files[i], rtcor = rtcor)
  }
  pdf(fn.tic, width = 16, height = 10)
  cols <- rainbow(num_sample, alpha = 0.8)
  lty = 1:num_sample
  pch = 1:num_sample
  xlim = range(sapply(tics, function(x) range(x[, 1], na.rm = TRUE)))
  ylim = range(sapply(tics, function(x) range(x[, 2], na.rm = TRUE)))
  plot(0, 0,
       type = "n",
       xlim = xlim,
       ylim = ylim,
       main = "Total Ion Chromatograms",
       xlab = "Retention Time",
       ylab = "tic")
  for (i in 1:num_sample) {
    tic <- tics[[i]]
    points(tic[, 1], tic[, 2], col = cols[i], pch = pch[i],
           type = "l")
  }
  legend("topright", paste(basename(files)),
         col = cols, lty = lty, pch = pch)
  dev.off()
  invisible(tics)
}

.get_tic <- function(fn, rtcor = NULL) {
  xraw <- xcms::xcmsRaw(fn)
  if (is.null(rtcor)) {
    rt <- xraw@scantime
  }
  else {
    rt <- rtcor
  }
  int <- xcms::rawEIC(xraw, mzrange = range(xraw@env$mz))$intensity
  cbind(rt, int)
}

.plot_feature_eic <- function(object, values,
                              filebase = "MS1",
                              eicmax = 1000,
                              h = 480,
                              w = 960,
                              mzdec = 2) {
  if (length(unique(xcms::peaks(object)[,"rt"])) > 1) {
    # This looks like "normal" LC data
    tsidx <- seq(nrow(xcms::groupval(object)))
    eicmax <- min(eicmax, length(tsidx))

    .cat_line(paste('Generatering', eicmax, 'EICs ...'))

    rtrange <- {
      extra <- 30
      rtmin <- apply(xcms::groupval(object, value = 'rtmin'), 1, median)
      rtmax <- apply(xcms::groupval(object, value = 'rtmax'), 1, median)
      pgidx <- tsidx[seq(length = eicmax)]
      rtrange_all <- range(object@rt)
      rt_start <- rtmin[pgidx] - extra
      rt_end   <- rtmax[pgidx] + extra
      rt_start[which(rt_start < rtrange_all[1])] <- rtrange_all[1]
      rt_end[which(rt_end > rtrange_all[2])] <- rtrange_all[2]
      unname(cbind(rt_start, rt_end))
    }

    ceic <- seq_along(object@filepaths)
    eics <- xcms::getEIC(object, rtrange = rtrange, sampleidx = ceic,
                         groupidx = tsidx[seq(length = eicmax)])

    if (length(filebase)) {
      eicdir <- paste(filebase, "EIC", sep = "")
      boxdir <- paste(filebase, "Box", sep = "")
      dir.create(eicdir)
      if (length(object@filepaths) > 1) {
        dir.create(boxdir)
        if (capabilities("png")) {
          xcms:::xcmsBoxPlot(values[seq(length = eicmax), , drop = FALSE],
                             xcms::sampclass(object),
                             dirpath = boxdir,
                             pic     = "png",
                             width   = w,
                             height  = h)
          png(file.path(eicdir, "%003d.png"), width = w, height = h)
        } else {
          xcms:::xcmsBoxPlot(values[seq(length = eicmax), , drop = FALSE],
                             xcms::sampclass(object),
                             dirpath = boxdir,
                             pic     = "pdf",
                             width   = w,
                             height  = h)
          pdf(file.path(eicdir, "%003d.pdf"),
              width   = w/72,
              height  = h/72,
              onefile = FALSE)
        }
      }
    }
    plot(eics, object, rtrange = rtrange, mzdec = mzdec)

    if (length(filebase))
      dev.off()
  } else {
    ## This looks like a direct-infusion single spectrum
    if (length(filebase)) {
      specdir <- paste(filebase, "_spec", sep = "")
      dir.create(specdir)
      if (capabilities("png")) {
        png(file.path(specdir, "%003d.png"), width = w, height = h)
      }else{
        pdf(file.path(eicdir, "%003d.pdf"), width = w/72,
            height = h/72, onefile = FALSE)
      }
    }

    xcms:::plotSpecWindow(object, gidxs = tsidx[seq(length = eicmax)], borderwidth = 1)

    if (length(filebase))
      dev.off()
  }
  invisible()
}

#' xcmsTools
#'
#' Processing MS data with `xcms`
#'
#' This package processes MS data for peak detection
#' to generate feature table and corresponding MSMS spectra.
#' @docType package
#' @author Yandong Yin (\email{yinyandong@@sioc.ac.cn})
#' @import xcms Cairo BiocParallel
#' @name xcmsTools
NULL

.onLoad <- function(libname, pkgname) {
  packageStartupMessage("\n======= WELCOME to ",
                        pkgname, " v", packageVersion(pkgname),
                        " ========",
                        "\nDeveloped by zhulab for MS Data Processing",
                        "\nImported packages:",
                        "\n  xcms v", packageVersion("xcms"),
                        "\n=============================================\n")
}


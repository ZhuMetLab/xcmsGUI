.show_info <- function(info) {
  paste0('*****', info, '*****\n')
}

.cat_line <- function(info) {
  sepLine <- paste(rep('-', 40), collapse = '')
  cat(' ', sepLine, paste0('  ', info), sepLine, sep = '\n')
}

.check_skip <- function(fn, use_previous, check_files = FALSE) {
  # check if use the existed results.
  a <- file.exists(fn) & use_previous
  if (a) {
    cat('Using previous results: ', fn, '\n')
    if (check_files) {
      xdata <- readRDS(fn)
      if (class(xdata) == 'xcmsSet') {
        if (!any(file.exists(xdata@filepaths))) {
          warning('Probaboly the previous data was moved.
            Trying to use files in current working dir instead.')
          xdata@filepaths <- unname(sapply(xdata@filepaths, function(file) {
            file <- list.files(pattern = basename(file), recursive = TRUE, full.names = TRUE)
            if (length(fn) != 1) {
              stop('Data files not found! Please check your data first or stop using previous data!')
            }
            file
          }))
          saveRDS(xdata, file = fn, version = 2)
        }
      }
    }
  }

  a
}

.load_data <- function(file, keep.name = FALSE, env){
  if (missing(env)) env <- new.env()
  b <- load(file, envir = env)
  if (keep.name | length( b) > 1) {
    r <- lapply( b, function(b1) env[[ b1]])
    names( r) <- b
    r
  } else {
    env[[b]]
  }
}

.make_unique_names <- function(name) {
  duplicated <- TRUE
  i <- 2
  while (duplicated) {
    idxDuplicated <- which(duplicated(name))
    if (length(idxDuplicated) > 0) {
      if (i == 2) {
        name[idxDuplicated] <- paste0(name[idxDuplicated], '_', i)
      } else {
        name[idxDuplicated] <- gsub(paste0('_', i - 1), paste0('_', i),
                                     name[idxDuplicated])
      }
      i <- i + 1
    } else {
      duplicated <- FALSE
    }
  }
  return(name)
}

.get_ppm_range <- function(mz, ppm, resDefineAt = 400) {
  mz + c(-1, 1) * max(prod(mz, ppm, 1e-06), prod(resDefineAt,
                                                 ppm, 1e-06))
}

.get_ppm_tol <- function(mz, ppm, resDefineAt = 400) {
  max(prod(mz, ppm, 1e-06), prod(resDefineAt,
                                 ppm, 1e-06))
}

.get_bpparam <- function(threads = 4, progressbar) {
  os = Sys.info()['sysname']
  BPPARAM = switch(os,
                   'Darwin' = {
                     BiocParallel::MulticoreParam(workers = threads,
                                                  progressbar = progressbar)
                   },
                   'Linux' = {
                     BiocParallel::SnowParam(workers = threads,
                                             progressbar = progressbar)
                   },
                   'Windows' = {
                     BiocParallel::SnowParam(workers = threads,
                                             progressbar = progressbar)
                   }
  )
}
